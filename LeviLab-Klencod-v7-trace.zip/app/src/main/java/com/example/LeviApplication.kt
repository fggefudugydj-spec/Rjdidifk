package com.example

import android.app.Application
import android.content.Context
import com.example.imported.McBootstrap

class LeviApplication : Application() {

    private var isMc = false

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        isMc = McBootstrap.isMcProcess()
        if (isMc) {
            McBootstrap.install(base)
        }
    }

    override fun onCreate() {
        super.onCreate()
        if (isMc) {
            McBootstrap.registerHooks(this)
        }
    }
}
